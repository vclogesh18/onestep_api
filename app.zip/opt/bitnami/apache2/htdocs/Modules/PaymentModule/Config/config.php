<?php

return [
    'name' => 'PaymentModule'
];
