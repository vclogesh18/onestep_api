<?php

namespace Modules\UserManagement\Http\Controllers\Api\V1;

use Illuminate\Routing\Controller;

class UserController extends Controller
{
    //
}
