<?php

return [
    'name' => 'ZoneManagement'
];
