<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BidModule\\Providers\\BidModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BidModule\\Providers\\BidModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);