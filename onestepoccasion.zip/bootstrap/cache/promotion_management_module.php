<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PromotionManagement\\Providers\\PromotionManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PromotionManagement\\Providers\\PromotionManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);