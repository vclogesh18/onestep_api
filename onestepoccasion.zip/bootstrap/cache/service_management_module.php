<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ServiceManagement\\Providers\\ServiceManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ServiceManagement\\Providers\\ServiceManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);