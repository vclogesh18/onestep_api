<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BusinessSettingsModule\\Providers\\BusinessSettingsModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BusinessSettingsModule\\Providers\\BusinessSettingsModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);