<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PaymentModule\\Providers\\PaymentModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PaymentModule\\Providers\\PaymentModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);