<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\UserManagement\\Providers\\UserManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\UserManagement\\Providers\\UserManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);