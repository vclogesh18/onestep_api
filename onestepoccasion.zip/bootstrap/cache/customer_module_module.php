<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CustomerModule\\Providers\\CustomerModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CustomerModule\\Providers\\CustomerModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);