<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ChattingModule\\Providers\\ChattingModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ChattingModule\\Providers\\ChattingModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);