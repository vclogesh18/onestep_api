<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ProviderManagement\\Providers\\ProviderManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ProviderManagement\\Providers\\ProviderManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);