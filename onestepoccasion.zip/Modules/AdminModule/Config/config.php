<?php

return [
    'name' => 'AdminModule'
];
